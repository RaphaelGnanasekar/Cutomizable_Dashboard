﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Data.SqlClient;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace DATAX_dashboard_customization.Controllers
{
    public class DashboardController : Controller
    {
        // GET: Dashboard
        public ActionResult Index()
        {
            return View();
        }

        public JsonResult GetWidgets()
        {
            string userid = "";
            if (Session["User"] != null)
                userid = Session["User"].ToString();

            DataTable table = new DataTable();
            using (var con = new SqlConnection(ConfigurationManager.ConnectionStrings["ConString"].ConnectionString))
            using (var cmd = new SqlCommand("UspDxGetUserWidgets", con))
            using (var da = new SqlDataAdapter(cmd))
            {
                cmd.Parameters.AddWithValue("userid", userid);
                cmd.CommandType = CommandType.StoredProcedure;
                da.Fill(table);
            }

            return Json((from obj in table.AsEnumerable() select new {
                id = obj.Field<int>("Widgetid"), name = obj.Field<string>("WidgetName"),
                col = obj.Field<int>("Xposn"), row = obj.Field<int>("Yposn"),
                sizeX = obj.Field<int>("Xsize"), sizeY = obj.Field<int>("Ysize")
            }), JsonRequestBehavior.AllowGet);
        }

        public JsonResult GetWidgetState()
        {
            string userid = "";
            if (Session["User"] != null)
                userid = Session["User"].ToString();

            DataTable table = new DataTable();
            using (var con = new SqlConnection(ConfigurationManager.ConnectionStrings["ConString"].ConnectionString))
            using (var cmd = new SqlCommand("UspDxGetUserWidgetState", con))
            using (var da = new SqlDataAdapter(cmd))
            {
                cmd.Parameters.AddWithValue("userid", userid);
                cmd.CommandType = CommandType.StoredProcedure;
                da.Fill(table);
            }

            return Json((from obj in table.AsEnumerable()
                         select new
                         {
                             WidgetState = obj.Field<string>("WidgetState")
                         }), JsonRequestBehavior.AllowGet);
        }

        [HttpPost]
        public JsonResult Savewidgetstate(JSONdataclass data)
        {
            string userid = "";
            if (Session["User"] != null)
                userid = Session["User"].ToString();

            string jsondata = data.jsondata;
            using (var con = new SqlConnection(ConfigurationManager.ConnectionStrings["ConString"].ConnectionString))
            using (var cmd = new SqlCommand("UspDxSaveUserWidgets", con))
            using (var da = new SqlDataAdapter(cmd))
            {
                con.Open();
                cmd.Parameters.AddWithValue("userid", userid);
                cmd.Parameters.AddWithValue("widgetlist", jsondata);
                cmd.CommandType = CommandType.StoredProcedure;
                cmd.ExecuteNonQuery();
                con.Close();
            }
            return Json(null, JsonRequestBehavior.AllowGet);
        }
    }

    public class JSONdataclass
    {
        public string jsondata { get; set; }
    }
}