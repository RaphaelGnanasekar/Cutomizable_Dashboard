﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Web;
using System.Web.Mvc;

namespace DATAX_dashboard_customization.Controllers
{
    public class LoginController : Controller
    {
        // GET: Login
        [HttpGet]
        public ActionResult Index()
        {
            return View();
        }

        [HttpPost]
        public RedirectToRouteResult Login(string userid)
        {
            Session["User"] = userid;
            return RedirectToAction("Index", "Dashboard");
        }
    }
}